// ======================================================
// Sauvegarde automatique de la collecte
// ======================================================
console.log("sauvegarde.js chargé");
let collecteModifiee = false;

function sauvegarderCollecte() {

    const collecte = {

        version: "2.13",

        dateSauvegarde: Date.now(),

        numeroWP,

        distanceCollecte,

        traceParcourue,

         waypoints: waypoints.map(wp => {

        const copie = { ...wp };

        delete copie.marqueur;

        return copie;

    })

    };

    localStorage.setItem(
        "CDSI69_Collecte",
        JSON.stringify(collecte)
    );
console.log(localStorage.getItem("CDSI69_Collecte"));
    collecteModifiee = false;

    console.log("Collecte sauvegardée");
}

function collecteModifieeDepuisDerniereSauvegarde() {

    collecteModifiee = true;

}

function restaurerCollecte() {

    

  console.log(">>> Début restauration");

    let texte = localStorage.getItem("CDSI69_Collecte");

    if (!texte) {
        console.log("Aucune sauvegarde trouvée.");
        return;
    }

    let collecte = JSON.parse(texte);

    // ===== Restauration des variables =====

    numeroWP = collecte.numeroWP;
    distanceCollecte = collecte.distanceCollecte;
    traceParcourue = collecte.traceParcourue;
    let points = traceParcourue.map(p => [
    p.latitude,
    p.longitude
]);
console.log("traceMarcheur =", traceMarcheur);
console.log("carte =", carte);
if (traceMarcheur) {
    traceMarcheur.setLatLngs(points);

    // Facultatif mais pratique : centrer la carte sur la trace
    console.log("Nombre de points =", traceMarcheur.getLatLngs().length);
console.log("Bounds =", traceMarcheur.getBounds());
   if (points.length > 1) {
    carte.fitBounds(traceMarcheur.getBounds(), {
        maxZoom: 17
    });
}

    console.log("Trace restaurée sur la carte.");
}

console.log("Points Leaflet :", points);

console.log("traceParcourue =", traceParcourue);

    console.log("numeroWP =", numeroWP);
    console.log("distanceCollecte =", distanceCollecte);

    // ===== Informations =====

    console.log("Version :", collecte.version);
    console.log("Waypoints :", collecte.waypoints.length);
    console.log("Points de trace :", collecte.traceParcourue.length);

    console.log(">>> Fin restauration");

debugTel(
    "Restauration",
    "Trace : " + traceParcourue.length +
    "\nWaypoints : " + waypoints.length
);

}
function verifierCollecteInterrompue() {

    let texte = localStorage.getItem("CDSI69_Collecte");

    if (!texte) {

        console.log("Aucune collecte interrompue.");

        return null;

    }

    console.log("Une collecte interrompue a été trouvée.");

    return JSON.parse(texte);

}
function afficherCollecteInterrompue(collecte) {

    document.getElementById("resumeCollecte").innerHTML =

        "<p><b>Version :</b> " + collecte.version + "</p>" +

        "<p><b>Waypoints :</b> " + collecte.waypoints.length + "</p>" +

        "<p><b>Distance :</b> " + collecte.distanceCollecte + " m</p>";

    document.getElementById("fenetreCollecte")
        .classList.remove("cache");

}
function fermerCollecteInterrompue() {

    document
        .getElementById("fenetreCollecte")
        .classList.add("cache");

}

  function reprendreCollecte() {

    console.log(">>> Reprise d'une collecte");

    // Fermer la popup
    fermerCollecteInterrompue();

    // Changer d'écran
    document.getElementById("cdsi_preparation").style.display = "none";
    document.getElementById("cdsi_collecte").style.display = "block";

    initialiserCarte();

setTimeout(() => {
    carte.invalidateSize();
    console.log("invalidateSize exécuté");
}, 100);

   if (!traceMarcheur) {
    traceMarcheur = L.polyline([], {
        color: "red",
        weight: 4
    }).addTo(carte);

    console.log("traceMarcheur créée pour la reprise");
}
setTimeout(() => {
    carte.invalidateSize();
    console.log("invalidateSize exécuté");
}, 100);
//    console.log("Avant restaurerCollecte()");
restaurerCollecte();
console.log("Après restaurerCollecte()");
}

document
    .getElementById("btnReprendreCollecte")
    .addEventListener(
        "click",
        reprendreCollecte
       
    );
      console.log("Événement Reprendre attaché");
   

